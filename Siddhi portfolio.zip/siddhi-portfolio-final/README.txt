Siddhi Jadhav - Portfolio
Open index.html in any browser (internet needed once for fonts).
Edit text in index.html. Colours are at the top of the <style> block.
To publish free: upload this folder to Netlify Drop or GitHub Pages.
